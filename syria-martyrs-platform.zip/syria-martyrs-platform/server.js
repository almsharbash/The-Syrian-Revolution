import express from 'express';
import pg from 'pg';
import rateLimit from 'express-rate-limit';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { nameKey, CATEGORIES, GOVERNORATES } from './lib/arabic.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PAGE_SIZE = 20;

if (!process.env.DATABASE_URL) {
  console.error('متغير DATABASE_URL غير موجود. انسخه من ملف .env.example');
  process.exit(1);
}

const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === 'false' ? false : { rejectUnauthorized: false },
});

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '300kb' }));
app.use(express.static(path.join(__dirname, 'public')));

// الحد من الإرسال المتكرر من العنوان نفسه
const submitLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 15,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'عدد كبير من المحاولات، حاول بعد قليل' },
});

// ---------- أدوات مساعدة ----------

const clean = (value, max = 200) =>
  typeof value === 'string' ? value.trim().replace(/\s+/g, ' ').slice(0, max) : '';

const isDate = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s));

const today = () => new Date().toISOString().slice(0, 10);

const PHOTO_RE = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;

// يغلف مسارات async ويحوّل أخطاء قاعدة البيانات إلى رسائل مفهومة
const wrap = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch((err) => {
    console.error(err);
    if (err.code === '23505') {
      return res.status(409).json({ error: 'هذا الاسم مسجّل مسبقاً من قبلك في هذه الفئة' });
    }
    if (err.code === '23514') {
      return res.status(400).json({ error: 'بيانات غير صالحة لهذا السجل' });
    }
    res.status(500).json({ error: 'حدث خطأ في الخادم' });
  });

// حماية مسارات الإدارة برمز سري
function requireAdmin(req, res, next) {
  const token = process.env.ADMIN_TOKEN || '';
  const given = req.get('x-admin-token') || '';
  const ok =
    token.length >= 16 &&
    given.length === token.length &&
    crypto.timingSafeEqual(Buffer.from(given), Buffer.from(token));
  if (!ok) return res.status(401).json({ error: 'غير مصرح' });
  next();
}

// التحقق من بيانات التسجيل وتنظيفها
function validate(body) {
  const errors = [];
  const d = {};

  d.category = body.category;
  if (!CATEGORIES.includes(d.category)) errors.push('نوع السجل غير صحيح');

  d.full_name = clean(body.full_name, 120);
  if (d.full_name.split(' ').length < 2) errors.push('يرجى كتابة الاسم الثلاثي على الأقل');
  d.name_key = nameKey(d.full_name);
  if (!d.name_key) errors.push('الاسم يجب أن يحتوي على حروف');

  d.status = null;
  if (d.category === 'detainee') {
    d.status = ['released', 'missing'].includes(body.status) ? body.status : null;
    if (!d.status) errors.push('يرجى اختيار حالة المعتقل: مُفرج عنه أو مفقود');
  }

  d.event_date = clean(body.event_date, 10);
  if (!isDate(d.event_date)) errors.push('يرجى إدخال التاريخ');
  else if (d.event_date > today()) errors.push('التاريخ لا يمكن أن يكون في المستقبل');

  d.governorate = clean(body.governorate, 50);
  if (!GOVERNORATES.includes(d.governorate)) errors.push('يرجى اختيار المحافظة');

  d.city = clean(body.city, 80) || null;
  d.area = clean(body.area, 80) || null;

  d.place_of_detention = null;
  if (d.category === 'detainee') {
    d.place_of_detention = clean(body.place_of_detention, 160) || null;
    if (!d.place_of_detention) errors.push('يرجى كتابة مكان الاحتجاز');
  }

  d.notes = clean(body.notes, 500) || null;
  d.contact = clean(body.contact, 120) || null;

  d.photo = null;
  if (body.photo) {
    if (typeof body.photo !== 'string' || body.photo.length > 150000 || !PHOTO_RE.test(body.photo)) {
      errors.push('الصورة غير صالحة أو كبيرة الحجم');
    } else {
      d.photo = body.photo;
    }
  }

  d.submitter_key = clean(body.submitter_key, 64);
  if (d.submitter_key.length < 16) errors.push('معرّف المستخدم غير صالح، أعد تحميل الصفحة');

  return { errors, d };
}

// أسماء معتمدة متشابهة لتنبيه المستخدم قبل الإرسال
async function findSimilar(category, key) {
  const { rows } = await pool.query(
    `SELECT id, full_name, governorate, city, to_char(event_date, 'YYYY-MM-DD') AS event_date,
            similarity(name_key, $2) AS score
     FROM records
     WHERE category = $1 AND review_status = 'approved'
       AND name_key % $2 AND similarity(name_key, $2) >= 0.6
     ORDER BY score DESC
     LIMIT 5`,
    [category, key]
  );
  return rows;
}

// ---------- المسارات العامة ----------

app.get('/api/health', (_req, res) => res.json({ ok: true }));

app.get('/api/meta', (_req, res) =>
  res.json({ governorates: GOVERNORATES, categories: CATEGORIES })
);

// العدادات: تُحسب من السجلات المعتمدة فقط
app.get(
  '/api/stats',
  wrap(async (_req, res) => {
    const { rows } = await pool.query(`
      SELECT category,
        COUNT(*) FILTER (WHERE review_status = 'approved')::int AS total,
        COUNT(*) FILTER (WHERE review_status = 'approved' AND status = 'released')::int AS released,
        COUNT(*) FILTER (WHERE review_status = 'approved' AND status = 'missing')::int AS missing
      FROM records
      GROUP BY category
    `);
    const out = {
      martyr: { total: 0 },
      missing: { total: 0 },
      detainee: { total: 0, released: 0, missing: 0 },
    };
    for (const r of rows) {
      out[r.category] =
        r.category === 'detainee'
          ? { total: r.total, released: r.released, missing: r.missing }
          : { total: r.total };
    }
    res.json(out);
  })
);

// البحث والتصفية والترقيم
app.get(
  '/api/records',
  wrap(async (req, res) => {
    const category = req.query.category;
    if (!CATEGORIES.includes(category)) {
      return res.status(400).json({ error: 'نوع غير صحيح' });
    }

    const params = [category];
    const where = ['category = $1', "review_status = 'approved'"];

    // يضيف شرطاً ويستبدل كل علامة ? بمعامل مرقّم
    const cond = (sql, ...values) => {
      const refs = values.map((v) => {
        params.push(v);
        return `$${params.length}`;
      });
      let i = 0;
      where.push(sql.replace(/\?/g, () => refs[i++]));
    };

    const key = nameKey(clean(req.query.q, 100));
    if (key) cond('(name_key % ? OR name_key LIKE ?)', key, `%${key}%`);

    const place = clean(req.query.place, 100).replace(/[%_\\]/g, '');
    if (place) {
      const p = `%${place}%`;
      cond(
        '(governorate ILIKE ? OR city ILIKE ? OR area ILIKE ? OR place_of_detention ILIKE ?)',
        p, p, p, p
      );
    }

    const governorate = clean(req.query.governorate, 50);
    if (GOVERNORATES.includes(governorate)) cond('governorate = ?', governorate);

    if (category === 'detainee' && ['released', 'missing'].includes(req.query.status)) {
      cond('status = ?', req.query.status);
    }

    if (isDate(req.query.from)) cond('event_date >= ?', req.query.from);
    if (isDate(req.query.to)) cond('event_date <= ?', req.query.to);

    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const whereSql = where.join(' AND ');

    const countRes = await pool.query(
      `SELECT COUNT(*)::int AS n FROM records WHERE ${whereSql}`,
      params
    );
    const total = countRes.rows[0].n;

    params.push(PAGE_SIZE, (page - 1) * PAGE_SIZE);
    const { rows } = await pool.query(
      `SELECT id, category, status, full_name,
              to_char(event_date, 'YYYY-MM-DD') AS event_date,
              governorate, city, area, place_of_detention, notes, photo
       FROM records
       WHERE ${whereSql}
       ORDER BY event_date DESC, id DESC
       LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );

    res.json({
      total,
      page,
      pages: Math.max(1, Math.ceil(total / PAGE_SIZE)),
      items: rows,
    });
  })
);

// تسجيل حالة جديدة (تبقى قيد المراجعة حتى يعتمدها المشرف)
app.post(
  '/api/records',
  submitLimiter,
  wrap(async (req, res) => {
    const { errors, d } = validate(req.body || {});
    if (errors.length) return res.status(400).json({ error: errors.join('، ') });

    const similar = await findSimilar(d.category, d.name_key);

    const { rows } = await pool.query(
      `INSERT INTO records
         (category, status, full_name, name_key, event_date, governorate, city, area,
          place_of_detention, notes, contact, photo, submitter_key)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
       RETURNING id`,
      [
        d.category, d.status, d.full_name, d.name_key, d.event_date, d.governorate,
        d.city, d.area, d.place_of_detention, d.notes, d.contact, d.photo, d.submitter_key,
      ]
    );

    res.status(201).json({
      id: rows[0].id,
      message: 'تم استلام التسجيل، وسيُنشر بعد المراجعة',
      similar,
    });
  })
);

// ---------- مسارات الإدارة ----------

// قائمة السجلات حسب الحالة
app.get(
  '/api/admin/records',
  requireAdmin,
  wrap(async (req, res) => {
    const status = ['pending', 'approved', 'rejected', 'merged'].includes(req.query.status)
      ? req.query.status
      : 'pending';
    const { rows } = await pool.query(
      `SELECT id, category, status, full_name,
              to_char(event_date, 'YYYY-MM-DD') AS event_date,
              governorate, city, area, place_of_detention, notes, contact, photo,
              review_status, merged_into
       FROM records
       WHERE review_status = $1
       ORDER BY created_at DESC
       LIMIT 200`,
      [status]
    );
    res.json({ items: rows });
  })
);

// أسماء متشابهة بين السجلات المعتمدة لاكتشاف التكرار
app.get(
  '/api/admin/duplicates',
  requireAdmin,
  wrap(async (req, res) => {
    const category = req.query.category;
    if (!CATEGORIES.includes(category)) {
      return res.status(400).json({ error: 'نوع غير صحيح' });
    }
    const { rows } = await pool.query(
      `SELECT a.id AS a_id, a.full_name AS a_name, a.governorate AS a_gov, a.city AS a_city,
              b.id AS b_id, b.full_name AS b_name, b.governorate AS b_gov, b.city AS b_city,
              similarity(a.name_key, b.name_key) AS score
       FROM records a
       JOIN records b ON a.category = b.category AND a.id < b.id AND b.name_key % a.name_key
       WHERE a.category = $1
         AND a.review_status = 'approved' AND b.review_status = 'approved'
         AND similarity(a.name_key, b.name_key) >= 0.7
       ORDER BY score DESC
       LIMIT 100`,
      [category]
    );
    res.json({ items: rows });
  })
);

// دمج سجل مكرر (from) داخل سجل معتمد (into)
app.post(
  '/api/admin/merge',
  requireAdmin,
  wrap(async (req, res) => {
    const from = Number(req.body.from);
    const into = Number(req.body.into);
    if (!from || !into || from === into) {
      return res.status(400).json({ error: 'معرّفات غير صحيحة' });
    }
    const target = await pool.query(
      "SELECT id FROM records WHERE id = $1 AND review_status = 'approved'",
      [into]
    );
    if (!target.rowCount) {
      return res.status(400).json({ error: 'السجل الهدف يجب أن يكون معتمداً' });
    }
    const r = await pool.query(
      "UPDATE records SET review_status = 'merged', merged_into = $2 WHERE id = $1",
      [from, into]
    );
    if (!r.rowCount) return res.status(404).json({ error: 'السجل غير موجود' });
    res.json({ ok: true });
  })
);

// اعتماد أو رفض أو إعادة للمراجعة
app.patch(
  '/api/admin/records/:id',
  requireAdmin,
  wrap(async (req, res) => {
    const status = req.body.review_status;
    if (!['pending', 'approved', 'rejected'].includes(status)) {
      return res.status(400).json({ error: 'حالة غير صحيحة' });
    }
    const r = await pool.query(
      'UPDATE records SET review_status = $2, merged_into = NULL WHERE id = $1',
      [Number(req.params.id), status]
    );
    if (!r.rowCount) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true });
  })
);

// تعديل بيانات السجل
const EDITABLE = {
  full_name: 120,
  event_date: 10,
  governorate: 50,
  city: 80,
  area: 80,
  place_of_detention: 160,
  notes: 500,
  contact: 120,
};
const REQUIRED = ['full_name', 'event_date', 'governorate'];

app.put(
  '/api/admin/records/:id',
  requireAdmin,
  wrap(async (req, res) => {
    const sets = [];
    const vals = [];

    for (const [field, max] of Object.entries(EDITABLE)) {
      if (!(field in req.body)) continue;
      const value = clean(req.body[field], max) || null;
      if (REQUIRED.includes(field) && !value) {
        return res.status(400).json({ error: `الحقل ${field} مطلوب` });
      }
      if (field === 'event_date' && value && !isDate(value)) {
        return res.status(400).json({ error: 'صيغة التاريخ غير صحيحة' });
      }
      if (field === 'governorate' && !GOVERNORATES.includes(value)) {
        return res.status(400).json({ error: 'محافظة غير صحيحة' });
      }
      vals.push(value);
      sets.push(`${field} = $${vals.length}`);
      if (field === 'full_name') {
        vals.push(nameKey(value));
        sets.push(`name_key = $${vals.length}`);
      }
    }

    if ('status' in req.body) {
      const s = req.body.status;
      if (s !== null && !['released', 'missing'].includes(s)) {
        return res.status(400).json({ error: 'حالة غير صحيحة' });
      }
      vals.push(s);
      sets.push(`status = $${vals.length}`);
    }

    if (!sets.length) return res.status(400).json({ error: 'لا توجد بيانات للتعديل' });

    vals.push(Number(req.params.id));
    const r = await pool.query(
      `UPDATE records SET ${sets.join(', ')} WHERE id = $${vals.length} RETURNING id`,
      vals
    );
    if (!r.rowCount) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true });
  })
);

// حذف نهائي (السجلات المدموجة فيه تعود للمراجعة)
app.delete(
  '/api/admin/records/:id',
  requireAdmin,
  wrap(async (req, res) => {
    const id = Number(req.params.id);
    await pool.query(
      "UPDATE records SET review_status = 'pending', merged_into = NULL WHERE merged_into = $1",
      [id]
    );
    const r = await pool.query('DELETE FROM records WHERE id = $1', [id]);
    if (!r.rowCount) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true });
  })
);

// ---------- التشغيل ----------

try {
  const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  await pool.query(schema);
  console.log('تم تجهيز قاعدة البيانات');
} catch (err) {
  console.error('فشل تجهيز قاعدة البيانات:', err.message);
  process.exit(1);
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`المنصة تعمل على http://localhost:${PORT}`));
