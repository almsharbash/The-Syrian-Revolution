const $ = (id) => document.getElementById(id);

const CAT = { martyr: 'شهيد', missing: 'مفقود', detainee: 'معتقل' };
const STATUS_AR = { released: 'مُفرج عنه', missing: 'مفقود' };

const getToken = () => sessionStorage.getItem('admin_token') || '';

async function api(url, options = {}) {
  const res = await fetch(url, {
    method: options.method || 'GET',
    headers: { 'Content-Type': 'application/json', 'x-admin-token': getToken() },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'حدث خطأ');
  return data;
}

function button(text, onClick, className) {
  const btn = document.createElement('button');
  btn.textContent = text;
  if (className) btn.className = className;
  btn.addEventListener('click', onClick);
  return btn;
}

async function setStatus(id, status) {
  try {
    await api(`/api/admin/records/${id}`, { method: 'PATCH', body: { review_status: status } });
    await loadList();
  } catch (err) {
    alert(err.message);
  }
}

async function editName(record) {
  const name = prompt('الاسم الكامل الجديد:', record.full_name);
  if (!name || name === record.full_name) return;
  try {
    await api(`/api/admin/records/${record.id}`, { method: 'PUT', body: { full_name: name } });
    await loadList();
  } catch (err) {
    alert(err.message);
  }
}

async function deleteRecord(id) {
  if (!confirm('حذف السجل نهائياً؟ لا يمكن التراجع عن ذلك.')) return;
  try {
    await api(`/api/admin/records/${id}`, { method: 'DELETE' });
    await loadList();
  } catch (err) {
    alert(err.message);
  }
}

function buildRow(r) {
  const box = document.createElement('article');
  box.className = 'admin-row';

  const info = document.createElement('div');
  const title = document.createElement('strong');
  let label = `#${r.id} — ${r.full_name} (${CAT[r.category]}`;
  if (r.status) label += ` / ${STATUS_AR[r.status]}`;
  title.textContent = label + ')';
  info.appendChild(title);

  const details = [
    r.event_date,
    r.governorate,
    r.city,
    r.area,
    r.place_of_detention,
    r.contact ? `تواصل: ${r.contact}` : '',
    r.notes,
  ].filter(Boolean).join(' | ');
  const p = document.createElement('p');
  p.textContent = details;
  info.appendChild(p);

  if (r.merged_into) {
    const m = document.createElement('p');
    m.textContent = `مدموج في السجل #${r.merged_into}`;
    info.appendChild(m);
  }
  box.appendChild(info);

  if (r.photo) {
    const img = document.createElement('img');
    img.src = r.photo;
    img.alt = '';
    box.appendChild(img);
  }

  const actions = document.createElement('div');
  actions.className = 'actions';
  if (r.review_status !== 'approved') {
    actions.appendChild(button('اعتماد', () => setStatus(r.id, 'approved')));
  }
  if (r.review_status !== 'rejected') {
    actions.appendChild(button('رفض', () => setStatus(r.id, 'rejected'), 'ghost'));
  }
  if (r.review_status !== 'pending') {
    actions.appendChild(button('إعادة للمراجعة', () => setStatus(r.id, 'pending'), 'ghost'));
  }
  actions.appendChild(button('تعديل الاسم', () => editName(r), 'ghost'));
  actions.appendChild(button('حذف', () => deleteRecord(r.id), 'danger'));
  box.appendChild(actions);

  return box;
}

async function loadList() {
  const status = $('statusSel').value;
  const data = await api(`/api/admin/records?status=${status}`);
  const list = $('list');
  list.textContent = '';
  if (!data.items.length) {
    list.textContent = 'لا توجد سجلات في هذه القائمة';
    return;
  }
  for (const r of data.items) list.appendChild(buildRow(r));
}

async function mergeInto(fromId, intoId) {
  if (!confirm(`دمج السجل #${fromId} داخل السجل #${intoId}؟`)) return;
  try {
    await api('/api/admin/merge', { method: 'POST', body: { from: fromId, into: intoId } });
    await loadDuplicates();
    await loadList();
  } catch (err) {
    alert(err.message);
  }
}

async function loadDuplicates() {
  const data = await api(`/api/admin/duplicates?category=${$('dupCat').value}`);
  const box = $('dups');
  box.textContent = '';
  if (!data.items.length) {
    box.textContent = 'لا توجد تكرارات محتملة';
    return;
  }
  for (const d of data.items) {
    const row = document.createElement('div');
    row.className = 'admin-row dup-row';

    const text = document.createElement('span');
    text.textContent =
      `#${d.a_id} ${d.a_name} (${d.a_gov}${d.a_city ? ' - ' + d.a_city : ''})` +
      `  ↔  #${d.b_id} ${d.b_name} (${d.b_gov}${d.b_city ? ' - ' + d.b_city : ''})` +
      `  — التشابه ${Math.round(d.score * 100)}%`;
    row.appendChild(text);

    const actions = document.createElement('div');
    actions.className = 'actions';
    actions.appendChild(button(`دمج #${d.b_id} في #${d.a_id}`, () => mergeInto(d.b_id, d.a_id), 'ghost'));
    actions.appendChild(button(`دمج #${d.a_id} في #${d.b_id}`, () => mergeInto(d.a_id, d.b_id), 'ghost'));
    row.appendChild(actions);

    box.appendChild(row);
  }
}

function showPanel(show) {
  $('loginSection').hidden = show;
  $('panel').hidden = !show;
}

async function login() {
  sessionStorage.setItem('admin_token', $('tokenInput').value.trim());
  try {
    await loadList();
    $('loginMsg').textContent = '';
    showPanel(true);
  } catch (err) {
    sessionStorage.removeItem('admin_token');
    $('loginMsg').textContent = 'رمز غير صحيح';
  }
}

function logout() {
  sessionStorage.removeItem('admin_token');
  showPanel(false);
}

function init() {
  $('loginBtn').addEventListener('click', login);
  $('tokenInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') login();
  });
  $('logoutBtn').addEventListener('click', logout);
  $('reloadBtn').addEventListener('click', () => loadList().catch((e) => alert(e.message)));
  $('statusSel').addEventListener('change', () => loadList().catch((e) => alert(e.message)));
  $('dupBtn').addEventListener('click', () => loadDuplicates().catch((e) => alert(e.message)));

  if (getToken()) {
    loadList()
      .then(() => showPanel(true))
      .catch(() => showPanel(false));
  }
}

init();
