const CAT_DATE = {
  martyr: 'تاريخ الاستشهاد',
  missing: 'تاريخ الاختفاء',
  detainee: 'تاريخ الاعتقال',
};

const state = {
  cat: 'martyr',
  page: 1,
  pages: 1,
  governorates: [],
  photo: null,
};

const $ = (id) => document.getElementById(id);

// معرّف ثابت للمتصفح يمنع تكرار الاسم من المستخدم نفسه
function getKey() {
  let key = localStorage.getItem('submitter_key');
  if (!key) {
    key = crypto.randomUUID
      ? crypto.randomUUID()
      : Date.now().toString(36) + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
    localStorage.setItem('submitter_key', key);
  }
  return key;
}

function formatDate(iso) {
  return iso ? iso.split('-').reverse().join('/') : '';
}

function fillGovernorates(select) {
  for (const g of state.governorates) {
    const option = document.createElement('option');
    option.value = g;
    option.textContent = g;
    select.appendChild(option);
  }
}

async function loadMeta() {
  const res = await fetch('/api/meta');
  state.governorates = (await res.json()).governorates;
  fillGovernorates($('govFilter'));
  fillGovernorates($('regGov'));
}

async function loadStats() {
  const res = await fetch('/api/stats');
  if (!res.ok) return;
  const s = await res.json();
  $('cnt-martyr').textContent = s.martyr.total;
  $('cnt-missing').textContent = s.missing.total;
  $('cnt-detainee').textContent = s.detainee.total;
  $('cnt-released').textContent = s.detainee.released;
  $('cnt-detained-missing').textContent = s.detainee.missing;
}

function renderCard(r) {
  const card = document.createElement('article');
  card.className = 'rec';

  if (r.photo) {
    const img = document.createElement('img');
    img.src = r.photo;
    img.alt = '';
    img.loading = 'lazy';
    card.appendChild(img);
  }

  const title = document.createElement('h3');
  title.textContent = r.full_name;
  card.appendChild(title);

  const lines = [
    [CAT_DATE[r.category], formatDate(r.event_date)],
    ['المحافظة', r.governorate],
    ['المدينة', r.city],
    ['المنطقة', r.area],
  ];
  if (r.category === 'detainee') {
    lines.push(['الحالة', r.status === 'released' ? 'مُفرج عنه' : 'مفقود']);
    lines.push(['مكان الاحتجاز', r.place_of_detention]);
  }
  if (r.notes) lines.push(['ملاحظات', r.notes]);

  for (const [label, value] of lines) {
    if (!value) continue;
    const p = document.createElement('p');
    const b = document.createElement('b');
    b.textContent = label + ': ';
    const span = document.createElement('span');
    span.textContent = value;
    p.append(b, span);
    card.appendChild(p);
  }
  return card;
}

async function loadRecords() {
  const params = new URLSearchParams();
  params.set('category', state.cat);
  params.set('page', state.page);

  for (const [key, value] of new FormData($('searchForm')).entries()) {
    if (!value) continue;
    if (key === 'status' && state.cat !== 'detainee') continue;
    params.set(key, value);
  }

  const res = await fetch('/api/records?' + params.toString());
  const data = await res.json();
  const results = $('results');
  results.textContent = '';

  if (!res.ok) {
    $('resultCount').textContent = data.error || 'تعذر تحميل النتائج';
    return;
  }

  state.pages = data.pages;
  $('resultCount').textContent = `عدد النتائج: ${data.total}`;
  $('pageInfo').textContent = `صفحة ${data.page} من ${data.pages}`;
  $('prev').disabled = data.page <= 1;
  $('next').disabled = data.page >= data.pages;

  if (!data.items.length) {
    const empty = document.createElement('p');
    empty.className = 'empty';
    empty.textContent = 'لا توجد نتائج مطابقة';
    results.appendChild(empty);
    return;
  }

  for (const item of data.items) results.appendChild(renderCard(item));
}

function setCategory(cat) {
  state.cat = cat;
  state.page = 1;
  document.querySelectorAll('.tab[data-cat]').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.cat === cat);
  });
  $('statusFilter').hidden = cat !== 'detainee';
  loadRecords();
}

function syncRegisterForm() {
  const cat = $('regCategory').value;
  const isDetainee = cat === 'detainee';
  $('statusBox').hidden = !isDetainee;
  $('detentionBox').hidden = !isDetainee;
  $('dateText').textContent = CAT_DATE[cat];
}

function showMessage(text, ok) {
  const box = $('formMsg');
  box.textContent = text;
  box.className = 'msg ' + (ok ? 'ok' : 'error');
  box.hidden = false;
}

// تصغير الصورة وضغطها لتبقى خفيفة في قاعدة البيانات
function resizeImage(file, maxSide = 160) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);

      let quality = 0.8;
      let out = canvas.toDataURL('image/jpeg', quality);
      while (out.length > 120000 && quality > 0.3) {
        quality -= 0.1;
        out = canvas.toDataURL('image/jpeg', quality);
      }
      URL.revokeObjectURL(url);
      resolve(out);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('تعذر قراءة الصورة'));
    };
    img.src = url;
  });
}

async function onPhotoChange(e) {
  const file = e.target.files[0];
  if (!file) return;
  if (!file.type.startsWith('image/') || file.size > 10 * 1024 * 1024) {
    showMessage('يرجى اختيار صورة لا تتجاوز 10 ميغابايت', false);
    e.target.value = '';
    return;
  }
  try {
    state.photo = await resizeImage(file);
    $('photoPreview').src = state.photo;
    $('photoPreview').hidden = false;
    $('removePhoto').hidden = false;
  } catch (err) {
    showMessage(err.message, false);
  }
}

function clearPhoto() {
  state.photo = null;
  $('photoInput').value = '';
  $('photoPreview').hidden = true;
  $('photoPreview').removeAttribute('src');
  $('removePhoto').hidden = true;
}

async function onRegisterSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const body = Object.fromEntries(new FormData(form).entries());
  body.submitter_key = getKey();
  body.photo = state.photo || '';

  const submitBtn = form.querySelector('button[type="submit"]');
  submitBtn.disabled = true;
  try {
    const res = await fetch('/api/records', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) {
      showMessage(data.error || 'تعذر الإرسال', false);
      return;
    }
    let text = data.message;
    if (data.similar && data.similar.length) {
      const names = data.similar.map((s) => `${s.full_name} (${s.governorate})`).join('، ');
      text += `. تنبيه: توجد أسماء متشابهة معتمدة: ${names}`;
    }
    showMessage(text, true);
    form.reset();
    clearPhoto();
    syncRegisterForm();
  } catch (err) {
    showMessage('تعذر الاتصال بالخادم، حاول لاحقاً', false);
  } finally {
    submitBtn.disabled = false;
  }
}

function bindEvents() {
  document.querySelectorAll('.tab[data-cat]').forEach((btn) => {
    btn.addEventListener('click', () => setCategory(btn.dataset.cat));
  });

  $('searchForm').addEventListener('submit', (e) => {
    e.preventDefault();
    state.page = 1;
    loadRecords();
  });

  $('resetBtn').addEventListener('click', () => {
    $('searchForm').reset();
    state.page = 1;
    loadRecords();
  });

  $('prev').addEventListener('click', () => {
    if (state.page > 1) {
      state.page -= 1;
      loadRecords();
    }
  });

  $('next').addEventListener('click', () => {
    if (state.page < state.pages) {
      state.page += 1;
      loadRecords();
    }
  });

  $('openRegister').addEventListener('click', () => {
    $('registerSection').hidden = false;
    $('registerSection').scrollIntoView({ behavior: 'smooth' });
  });

  $('closeRegister').addEventListener('click', () => {
    $('registerSection').hidden = true;
  });

  $('regCategory').addEventListener('change', syncRegisterForm);
  $('photoInput').addEventListener('change', onPhotoChange);
  $('removePhoto').addEventListener('click', clearPhoto);
  $('registerForm').addEventListener('submit', onRegisterSubmit);

  $('regDate').max = new Date().toISOString().slice(0, 10);
}

async function init() {
  bindEvents();
  syncRegisterForm();
  try {
    await loadMeta();
    await Promise.all([loadStats(), loadRecords()]);
  } catch (err) {
    $('resultCount').textContent = 'تعذر الاتصال بالخادم';
  }
}

init();
