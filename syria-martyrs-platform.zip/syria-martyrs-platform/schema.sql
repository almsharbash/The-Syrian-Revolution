-- تفعيل امتداد البحث بالتشابه (لكشف الأسماء المتشابهة والمكررة)
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE IF NOT EXISTS records (
  id                  BIGSERIAL PRIMARY KEY,
  category            TEXT NOT NULL CHECK (category IN ('martyr', 'missing', 'detainee')),
  -- خاصة بالمعتقلين فقط: released = مُفرج عنه ، missing = مفقود
  status              TEXT CHECK (status IN ('released', 'missing')),
  full_name           TEXT NOT NULL,
  -- الاسم بعد التطبيع (بدون تشكيل وتوحيد الهمزات) ويُستخدم للبحث والمقارنة
  name_key            TEXT NOT NULL,
  event_date          DATE NOT NULL,
  governorate         TEXT NOT NULL,
  city                TEXT,
  area                TEXT,
  place_of_detention  TEXT,
  notes               TEXT,
  -- بيانات التواصل: لا تظهر للعامة أبداً
  contact             TEXT,
  -- صورة مصغرة اختيارية (data URL)
  photo               TEXT,
  -- معرّف المتصفح/الجهاز لمنع تكرار الاسم من المستخدم نفسه
  submitter_key       TEXT,
  review_status       TEXT NOT NULL DEFAULT 'pending'
                      CHECK (review_status IN ('pending', 'approved', 'rejected', 'merged')),
  -- عند دمج سجل مكرر في سجل آخر
  merged_into         BIGINT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT detainee_needs_status CHECK (category <> 'detainee' OR status IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS idx_records_list
  ON records (category, review_status, event_date DESC);

CREATE INDEX IF NOT EXISTS idx_records_name_trgm
  ON records USING GIN (name_key gin_trgm_ops);

CREATE INDEX IF NOT EXISTS idx_records_governorate
  ON records (governorate);

-- منع تكرار الاسم نفسه من المستخدم نفسه في الفئة نفسها
CREATE UNIQUE INDEX IF NOT EXISTS uniq_user_name
  ON records (submitter_key, name_key, category)
  WHERE submitter_key IS NOT NULL AND review_status IN ('pending', 'approved');
